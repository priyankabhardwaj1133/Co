<?php
// Start the session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include your database connection file
include "db-connection.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}

// Fetch all meetings and their comments from the database
$sql = "
    SELECT 
        m.id AS meeting_id, 
        m.project_name, 
        m.department, 
        m.meeting_date, 
        m.file_name, 
        m.description, 
        c.comment, 
        c.comment_date, 
        s.username, 
        s.image_path 
    FROM 
        meeting m
    LEFT JOIN 
        comments c ON m.id = c.meeting_id
    LEFT JOIN 
        signin s ON c.user_id = s.id
    ORDER BY 
        m.meeting_date ASC, c.comment_date DESC";
$result = $conn->query($sql);

// Initialize an array to hold meetings and their comments
$meetings = [];
if ($result->num_rows > 0) {    
    while ($row = $result->fetch_assoc()) {
        $meetings[$row['meeting_id']]['details'] = [
            'project_name' => $row['project_name'],
            'department' => $row['department'],
            'meeting_date' => $row['meeting_date'],
            'file_name' => $row['file_name'],
            'description' => $row['description']
        ];
        if ($row['comment']) {
            $meetings[$row['meeting_id']]['comments'][] = [
                'comment' => $row['comment'],
                'comment_date' => $row['comment_date'],
                'username' => $row['username'],
                'image_path' => $row['image_path']
            ];
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Analytics & Report</h1>
            </div>

            <div class="dashboard-table wd100">
                <div class="search-bar">
                    <input type="text" placeholder="Search">
                </div>
                <ul>
                    <li class="head">
                        <div class="dashboard-checkbox">
                            <input type="checkbox">
                        </div>
                        <div class="dashboard-name">
                            Name
                        </div>
                        <div class="dashboard-department">
                            Department
                        </div>
                        <div class="dashboard-documents">
                            Documents
                        </div>
                        <div class="dashboard-description">
                            Description
                        </div>
                        <div class="dashboard-date">
                            Date/Time
                        </div>
                        <div class="dashboard-more">
                            Reports
                        </div>
                    </li>

                    <?php foreach ($meetings as $meeting_id => $meeting): ?>
                    <li>
                        <div class="dashboard-checkbox">
                            <input type="checkbox">
                        </div>
                        <div class="dashboard-name">
                            <?php echo htmlspecialchars($meeting['details']['project_name']); ?>
                        </div>
                        <div class="dashboard-department">
                            <?php echo htmlspecialchars($meeting['details']['department']); ?>
                        </div>
                        <div class="dashboard-documents">
                            <?php echo htmlspecialchars($meeting['details']['file_name']); ?>
                        </div>
                        <div class="dashboard-description">
                            <?php echo htmlspecialchars($meeting['details']['description']); ?>
                        </div>
                        <div class="dashboard-date">
                            <?php echo htmlspecialchars(date('d-m-y / h:iA', strtotime($meeting['details']['meeting_date']))); ?>
                        </div>
                        <div class="dashboard-more">
                            <ul>
                                <?php if (isset($meeting['comments'])): ?>
                                    <?php foreach ($meeting['comments'] as $comment): ?>
                                    <li>
                                        <div class="comment-text">
                                            <strong><?php echo htmlspecialchars($comment['username']); ?>:</strong>
                                            <?php echo htmlspecialchars($comment['comment']); ?>
                                            <span><?php echo htmlspecialchars($comment['comment_date']); ?></span>
                                        </div>
                                    </li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li>No comments</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>
