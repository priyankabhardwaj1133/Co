<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'db-connection.php'; // Include your database connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}

// Fetch upcoming meeting details from the database
$sql = "SELECT id, project_name, department, meeting_date, file_name, description FROM meeting WHERE meeting_date >= NOW() ORDER BY meeting_date ASC";
$result = $conn->query($sql);

$meetings = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $meetings[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include "user-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Upcoming Meeting</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Upcoming Meeting</h1>
            </div>
            <div class="user-manage-area wd100">
                <ul>
                    <?php foreach ($meetings as $meeting): ?>
                    <li>
                        <div class="user-manage-area-top">
                            <div class="user-manage-area-top-text">
                                <h3><?php echo htmlspecialchars($meeting['project_name']); ?></h3>
                                <p><?php echo htmlspecialchars($meeting['description']); ?></p>
                                <span><?php echo htmlspecialchars(date('d/m/Y - h:i A', strtotime($meeting['meeting_date']))); ?></span>
                            </div>
                        </div>
                        <div class="user-manage-area-middle">
                            <span><?php echo htmlspecialchars($meeting['department']); ?></span>
                        </div>
                        <div class="user-manage-area-footer">
                            <a href="view-meeting.php?id=<?php echo $meeting['id']; ?>" class="btn btn-blue">View Meeting</a>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>
