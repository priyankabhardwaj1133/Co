<?php
include "db-connection.php";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO meeting (project_name, department, meeting_date, file_name, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $projectName, $department, $meetingDate, $fileName, $description);

    // Get data from form
    $projectName = $_POST['project_name'] ?? '';
    $department = $_POST['department'] ?? '';
    $meetingDate = $_POST['meeting_date'] ?? '';
    $description = $_POST['description'] ?? '';
    $fileName = '';  // Default file name empty

	// Handle file upload if included
    if (isset($_FILES['file_upload']) && $_FILES['file_upload']['error'] == 0) {
        $targetDirectory = "uploads/";
        $fileName = basename($_FILES["file_upload"]["name"]);
        $targetFilePath = $targetDirectory . $fileName;
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

        if (!file_exists($targetFilePath)) {
            if (move_uploaded_file($_FILES["file_upload"]["tmp_name"], $targetFilePath)) {
                echo "The file " . htmlspecialchars($fileName) . " has been uploaded.";
            } else {
                echo "Error uploading your file.";
            }
        } else {
            echo "Sorry, file already exists.";
        }
	} else {
        echo "No file uploaded or an error occurred.";
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

?>
<html>
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
	<div class="wrapper">
		<div class="dashboard-content">
			<div class="dashboard-content-title wd100">
				<h1>Creating Meeting </h1>
			</div>

			<div class="creating-panel wd100">
				<form action="create-meeting-manager.php" method="post" enctype="multipart/form-data">
					<div class="left-right">
						<div class="left-p">
							<input type="text"  name="project_name" placeholder="Project Name">
						</div>
						<div class="right-p">
						<select name="department" value="department">
								<option value="it department">IT Department</option>
								<option value="finance department">Finance Department</option>
							</select>
						</div>
					</div>
					<div class="left-right">
						<div class="left-p">
						<input type="date" name="meeting_date" value="meeting_date" placeholder="Calendar & Time">
						</div>
						<div class="right-p">
						<input type="file" class="btn grey wdauto" name="file_upload"> 
						</div>
					</div>
					<div class="left-right">
							<textarea placeholder="Description" name="description" value="description"></textarea>

					</div>
					<div class="left-right">
						<input class="btn-area wdauto" value="Submit" type="submit">
						<input class="btn-area btn-area-black wdauto" value="Cancel" type="button" onclick="window.location.href='dashboard.php';">
					</div>
				</form>
			</div>



		</div>


	</div>












	<div class="wrapper">

		<div class="copyright wd100">
			<p>© CollaborateGov 2024 | All Right Reserved</p>
		</div>
	</div>

</body>
</html>
