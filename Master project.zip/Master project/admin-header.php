<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db-connection.php"; // Ensure this file contains your database connection code

function isActive($page) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    if ($currentFile == $page) {
        return 'class="active"';
    }
    return '';
}

function getCreateButtonLink() {
    $currentFile = basename($_SERVER['PHP_SELF']);
    if ($currentFile == 'meeting-management.php') {
        return 'create-meeting-manager.php';
    } elseif ($currentFile == 'user-management.php') {
        return 'create-user.php';
    }
    return '';
}

function showCreateButton() {
    $currentFile = basename($_SERVER['PHP_SELF']);
    return $currentFile == 'meeting-management.php' || $currentFile == 'user-management.php';
}

// Fetch comments and user information from the database
$comments_sql = "
    SELECT comments.comment, comments.comment_date, signin.username, signin.image_path 
    FROM comments 
    JOIN signin ON comments.user_id = signin.id 
    ORDER BY comments.comment_date DESC";
$comments_result = $conn->query($comments_sql);

// Initialize an empty array to hold comments
$comments = [];
if ($comments_result) {
    if ($comments_result->num_rows > 0) {    
        while ($row = $comments_result->fetch_assoc()) {
            $comments[] = $row;
        }
    }
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
    <link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
    <style>
        .active {
            color: #ff0000; /* Change this to whatever style you want for the active link */
            font-weight: bold;
        }

        .create-button {
            display: inline-block;
            margin-left: 15px; /* Adjust margin as needed */
        }

        .create-button .btn {
            background-color: #007bff;
            color: white !important;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        .create-button .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="header-dashboard wd100">
        <div class="wrapper">
            <div class="header wd100">
                <div class="logo">
                    <a href="index.php"><img width="230px" src="images/logo.png"></a>
                </div>
                <div class="main-menu dashboard">
                    <ul>
                        <li><a href="dashboard.php" <?php echo isActive('dashboard.php'); ?>>Dashboard</a></li>
                        <li><a href="meeting-management.php" <?php echo isActive('meeting-management.php'); ?>>Meeting Management</a></li>
                        <li><a href="user-management.php" <?php echo isActive('user-management.php'); ?>>User Management</a></li>
                        <li><a href="analytics-reports.php" <?php echo isActive('analytics-reports.php'); ?>>Analytics & Report</a></li>
                        <?php if (showCreateButton()): ?>
                            <li class="create-button"><a href="<?php echo getCreateButtonLink(); ?>" class="btn btn-primary">Create</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="sign-button dashboard-icons">
                    <ul>
                        <li><a href="#"><img src="images/ic_baseline-notifications.png"></a>
                            <div class="dashboard-content-notification wd100 menu-notification">
                                <div class="dashboard-content-subtitle wd100">
                                    <h2>Notifications</h2>
                                </div>
                                <ul>
                                    <?php foreach ($comments as $comment): ?>
                                    <li>
                                        <div class="notification-image">
                                            <img src="<?php echo htmlspecialchars($comment['image_path']); ?>" alt="User Image">
                                        </div>
                                        <div class="notification-text">
                                            <h4><?php echo htmlspecialchars($comment['username']); ?></h4>
                                            <p><?php echo htmlspecialchars($comment['comment']); ?></p>
                                        </div>
                                        <div class="notification-date">
                                            <span><?php echo htmlspecialchars($comment['comment_date']); ?></span>
                                        </div>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </li>
                        <li><a href="help.php"><img src="images/material-symbols_help.png"></a></li>
                        <li class="name-profile"><a href="view-profile.php" class="name-circle">
                            <?php
                            // Check if the username is set in the session and display it
                            if (isset($_SESSION["username"])) {
                                echo "Welcome, " . htmlspecialchars($_SESSION["username"]);
                            } else {
                                echo "Username not set.";
                            }
                            ?>
                        </a></li>
                        <li><a href="logout.php"><img src="images/logout.png" alt="Logout"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
