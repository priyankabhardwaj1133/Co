<?php
session_start(); // Start the session
require 'db-connection.php'; // Include your database connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}

// Get the meeting ID from the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $meeting_id = intval($_GET['id']);
} else {
    echo "Invalid meeting ID.";
    exit();
}

// Handle comment submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['comment'])) {
    $comment = trim($_POST['comment']);
    $user_id = $_SESSION['user_id'];

    if (!empty($comment)) {
        $stmt = $conn->prepare("INSERT INTO comments (meeting_id, user_id, comment) VALUES (?, ?, ?)");
        if ($stmt === false) {
            die('Prepare failed: ' . htmlspecialchars($conn->error));
        }
        $stmt->bind_param("iis", $meeting_id, $user_id, $comment);
        if ($stmt->execute()) {
            echo "Comment submitted successfully.";
        } else {
            echo "Error submitting comment: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Comment cannot be empty.";
    }
}

// Fetch meeting details from the database
$sql = "SELECT project_name, department, meeting_date, file_name, description FROM meeting WHERE id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}
$stmt->bind_param("i", $meeting_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $meeting = $result->fetch_assoc();
} else {
    echo "Meeting not found.";
    exit();
}
$stmt->close();

// Fetch comments for the meeting
$sql = "SELECT c.comment, c.comment_date, s.username, s.image_path FROM comments c JOIN signin s ON c.user_id = s.id WHERE c.meeting_id = ? ORDER BY c.comment_date DESC";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}
$stmt->bind_param("i", $meeting_id);
$stmt->execute();
$comments_result = $stmt->get_result();
$comments = [];
while ($row = $comments_result->fetch_assoc()) {
    $comments[] = $row;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include "user-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>View Meeting</h1>
            </div>

            <div class="view-panel wd100">
                <div class="wd100">
                    <h6>Project Name</h6>
                    <p><?php echo htmlspecialchars($meeting['project_name']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Department</h6>
                    <p><?php echo htmlspecialchars($meeting['department']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Meeting Date</h6>
                    <p><?php echo htmlspecialchars(date('d-m-Y / h:iA', strtotime($meeting['meeting_date']))); ?></p>
                </div>

                <div class="wd100">
                    <h6>Documents</h6>
                    <p><a href="uploads/<?php echo htmlspecialchars($meeting['file_name']); ?>" target="_blank"><?php echo htmlspecialchars($meeting['file_name']); ?></a></p>
                </div>

                <div class="wd100">
                    <h6>Description</h6>
                    <p><?php echo htmlspecialchars($meeting['description']); ?></p>
                </div>

                <div id="comment-feedback" class="wd100">
                    <h6>Comments</h6>
                    <form class="form-feedback" method="post" action="">
                        <textarea name="comment" placeholder="Feedback" required></textarea>
                        <input class="btn-area wdauto" value="Submit" type="submit">
                    </form>

                    <div class="user-manage-area wd100">
                        <ul>
                            <?php foreach ($comments as $comment): ?>
                            <li>
                                <div class="user-manage-area-top">
                                    <div class="user-manage-area-top-image">
                                        <img src="<?php echo htmlspecialchars($comment['image_path']); ?>" alt="Profile Image">
                                    </div>
                                    <div class="user-manage-area-top-text">
                                        <h3><?php echo htmlspecialchars($comment['username']); ?></h3>
                                        <span><?php echo htmlspecialchars(date('d/m/Y - h:iA', strtotime($comment['comment_date']))); ?></span>
                                    </div>
                                </div>
                                <div class="user-manage-area-middle">
                                    <p><?php echo htmlspecialchars($comment['comment']); ?></p>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>

</body>
</html>
