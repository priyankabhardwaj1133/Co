<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Forgot Password</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>

<?php
$message = "hi";

try {
    $serverName = "comp9034-group2-ae.database.windows.net"; // Azure server name
    $database = "comp9034-group2-db"; // Azure database name
    $username = "admincomp9034group2"; // Database username
    $password = "flinders@tonsley9034"; // Database password

    try {
        $conn = new PDO("sqlsrv:server = $serverName; Database = $database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }

    // Check if the form has been submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['email'])) {
        $email = $_POST['email'];

        // Prepare a SELECT statement to check if the email exists in the database
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $message = "Email exists. A reset link has been sent to: " . htmlspecialchars($email);
            // Here you would typically send an email or perform some other action
        } else {
            $message = "No account found with that email address.";
        }
    }
} catch (PDOException $e) {
    // Handle any database connection error or query error
    $message = "Database error: " . $e->getMessage();
}
?>

    <div class="wd100">
        <div class="signarea">
            <div class="signarea-content">
                <p><a href="index.php"><img width="70%" src="images/logo.png" alt="Logo"></a></p>
                <h1>Forgot Password</h1>
                <p>Enter your email below to reset your Password</p>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <input type="email" name="email" placeholder="Email Id" required>
                    <input class="btn" value="Submit" type="submit">
                </form>
                <p style="color:green;"><?php echo $message; ?></p>
                <p align="middle"><strong>Already have an account? <a href="signin.php">Sign in</a></strong></p>
            </div>
            <div class="signarea-image" style="background:url('images/signin.png') no-repeat center center / cover;"></div>
        </div>
    </div>

</body>
</html>
