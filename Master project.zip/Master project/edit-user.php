<?php
session_start();
require_once 'db-connection.php'; // Include your database connection file

// Get user ID from the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);

    // Fetch user data from the database
    $sql = "SELECT * FROM signin WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    // Check if user data was found
    if (!$user) {
        $_SESSION['error'] = "User not found.";
        header("Location: view-user.php"); // Redirect to view-user.php
        exit();
    }
} else {
    // Handle the case where 'id' parameter is missing or invalid
    $_SESSION['error'] = "Invalid or missing user ID.";
    header("Location: view-user.php"); // Redirect to view-user.php
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $id = intval($_POST['id']);
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $usertype = $_POST['usertype'];
    $department = $_POST['department'];
    $member_id = $_POST['member_id'];

    // Handle file upload
    $image_path = $user['image_path']; // Keep current image path if no new image is uploaded
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if file is an image
        $check = getimagesize($_FILES["profile_image"]["tmp_name"]);
        if ($check !== false) {
            // Check file size (limit to 2MB)
            if ($_FILES["profile_image"]["size"] <= 2000000) {
                // Allow certain file formats
                if (in_array($imageFileType, array("jpg", "png", "jpeg", "gif"))) {
                    // Move uploaded file to target directory
                    if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
                        $image_path = $target_file;
                    } else {
                        $_SESSION['error'] = "Sorry, there was an error uploading your file.";
                    }
                } else {
                    $_SESSION['error'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                }
            } else {
                $_SESSION['error'] = "Sorry, your file is too large.";
            }
        } else {
            $_SESSION['error'] = "File is not an image.";
        }
    }

    // Update user data in the database
    $sql = "UPDATE signin SET username = ?, password = ?, email = ?, usertype = ?, department = ?, member_id = ?, image_path = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    if (!$stmt->bind_param("sssssssi", $username, $password, $email, $usertype, $department, $member_id, $image_path, $id)) {
        die('Bind param failed: ' . htmlspecialchars($stmt->error));
    }

    if ($stmt->execute()) {
        $_SESSION['success'] = "User updated successfully.";
        $stmt->close();
        header("Location: view-user.php?id=$id"); // Redirect to view-user.php with user ID
        exit();
    } else {
        $_SESSION['error'] = "Failed to update user.";
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<?php include "admin-header.php"; ?>
<style>
    .custom-file-input {
        display: none;
    }
    .btn-custom-upload {
        background-color: #000;
        color: #fff;
        padding: 10px 20px;
        cursor: pointer;
        display: inline-block;
        text-align: center;
    }
    .btn-custom-remove {
        background-color: #ff0000;
        color: #fff;
        padding: 10px 20px;
        cursor: pointer;
        display: inline-block;
        text-align: center;
    }
    .btn-area {
        margin-top: 10px;
    }
    #profile_image_preview {
        display: block;
        margin-bottom: 10px;
    }
</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Edit Member</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
<div class="wrapper">
    <div class="dashboard-content">
        <div class="dashboard-content-title wd100">
            <h1>Edit Member</h1>
        </div>

        <div class="creating-panel wd100">
            <?php if (isset($_SESSION['error'])): ?>
                <div class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <form action="edit-user.php?id=<?php echo htmlspecialchars($user['id']); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">
                <div class="left-right">
                    <div class="user-profile-manage-image">
                        <img id="profile_image_preview" src="<?php echo htmlspecialchars($user['image_path']); ?>" alt="Profile Image">
                    </div>
                    <label for="profile_image" class="btn-custom-upload">UPLOAD</label>
                    <input type="file" name="profile_image" id="profile_image" class="custom-file-input" accept="image/*">
                    <button type="button" class="btn-custom-remove" onclick="removeImage()">REMOVE</button>
                    <input type="hidden" name="remove_image" id="remove_image" value="false">
                </div>
                <div class="left-right">
                    <div class="left-p">
                        <input type="text" name="username" placeholder="Username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>
                    <div class="right-p">
                        <input type="text" name="password" placeholder="Password" value="<?php echo htmlspecialchars($user['password']); ?>" required>
                    </div>
                </div>
                <div class="left-right">
                    <div class="left-p">
                        <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    <div class="right-p">
                        <select name="usertype" required>
                            <option value="admin" <?php echo $user['usertype'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                            <option value="user" <?php echo $user['usertype'] == 'user' ? 'selected' : ''; ?>>User</option>
                        </select>
                    </div>
                </div>
                <div class="left-right">
                    <div class="left-p">
                        <input type="text" name="member_id" placeholder="Member Id" value="<?php echo htmlspecialchars($user['member_id']); ?>" required>
                    </div>
                    <div class="right-p">
                    <select name="department" required>
                            <option value="it department" <?php echo $user['department'] == 'it department' ? 'selected' : ''; ?>>IT Department</option>
                            <option value="finanace department" <?php echo $user['department'] == 'finanace department' ? 'selected' : ''; ?>>Finance Department</option>
                        </select>
                    </div>
                </div>
                <div class="left-right">
                    <input class="btn-area wdauto" value="Submit" type="submit">
                    <input class="btn-area btn-area-black wdauto" value="Cancel" type="button" onclick="window.location.href='dashboard.php';">
                </div>
            </form>
        </div>
    </div>
</div>

<div class="wrapper">
    <div class="copyright wd100">
        <p>© CollaborateGov 2024 | All Right Reserved</p>
    </div>
</div>

</body>
</html>
<script>
document.getElementById('profile_image').addEventListener('change', function(event) {
    var reader = new FileReader();
    reader.onload = function(e) {
        var imgElement = document.getElementById('profile_image_preview');
        imgElement.src = e.target.result;
        imgElement.style.display = 'block';
    }
    reader.readAsDataURL(event.target.files[0]);
});

function removeImage() {
    var imgElement = document.getElementById('profile_image_preview');
    imgElement.src = '';
    imgElement.style.display = 'none';
    document.getElementById('profile_image').value = '';
    document.getElementById('remove_image').value = 'true';
}
</script>
