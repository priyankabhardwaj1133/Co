<?php
include "db-connection.php";

// Check if ID is set in the URL and is numeric
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM meeting WHERE id = ?");
    
    // Check if the prepare() method succeeded
    if ($stmt === false) {
        die('Prepare() failed: ' . htmlspecialchars($conn->error));
    }
    
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Check if the delete was successful
    if ($stmt->affected_rows > 0) {
        // Redirect to dashboard or another relevant page after deletion
        header("Location: dashboard.php"); // Change 'dashboard.php' to your actual dashboard or list page
        exit;
    } else {
        echo "No meeting found with the provided ID, or delete operation failed.";
    }

    $stmt->close();
} else {
    echo "Invalid meeting ID.";
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>View Meeting Details</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
<script>
function confirmDeletion(id) {
    if (confirm("Are you sure you want to delete this meeting?")) {
        window.location.href = 'delete-meeting.php?id=' + id;
    }
}
</script>
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>View Meeting Details</h1>
            </div>

            <div class="view-panel wd100">
                <div class="wd100">
                    <h6>Project Name</h6>
                    <p><?php echo htmlspecialchars($meeting['project_name']); ?></p>
                </div>
                <div class="wd100">
                    <h6>Department</h6>
                    <p><?php echo htmlspecialchars($meeting['department']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Documents</h6>
                    <p><a href="uploads/<?php echo htmlspecialchars($meeting['file_name']); ?>" target="_blank"><?php echo htmlspecialchars($meeting['file_name']); ?></a></p>
                </div>
                <div class="wd100">
                    <h6>Description</h6>
                    <p><?php echo htmlspecialchars($meeting['description']); ?></p>
                </div>
                <div class="wd100">
                    <h6>Calendar & Time</h6>
                    <p><?php echo htmlspecialchars($meeting['meeting_date']); ?></p>
                </div>
                <div class="wd100">
                    <h6>More Actions</h6>
                    <p>
                        <a href="edit-meeting.php?id=<?php echo $meeting['id']; ?>"><img src="images/edit.png"></a>
                        <a href="schedule-meeting.php?id=<?php echo $meeting['id']; ?>"><img src="images/schedule.png"></a>
                        <a href="javascript:void(0);" onclick="confirmDeletion(<?php echo $meeting['id']; ?>)"><img src="images/delete.png"></a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>

</body>
</html>
