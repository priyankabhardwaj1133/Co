<?php
include "db-connection.php";
$imagePath = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadDir = 'uploads/';
    
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == UPLOAD_ERR_OK) {
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
        $fileExtension = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);

        if (in_array(strtolower($fileExtension), $allowedExtensions)) {
            $uploadFile = $uploadDir . basename($_FILES['profile_image']['name']);
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $uploadFile)) {
                $imagePath = $uploadFile;
                echo "Image uploaded successfully: $imagePath<br>";
            } else {
                echo "Error uploading the file.";
                exit();
            }
        } else {
            echo "Invalid file type.";
            exit();
        }
    }

    if (isset($_POST['remove_image']) && $_POST['remove_image'] == 'true') {
        $imagePath = ''; // or set a default image path if required
    }

    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $department = $_POST['department'];
    $usertype = $_POST['usertype'];
    $member_id = $_POST['member_id'];

    $sql = "INSERT INTO signin (username, password, email, usertype, member_id, image_path, department) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    if (!$stmt->bind_param("sssssss", $username, $password, $email, $usertype, $member_id, $imagePath, $department)) {
        die('Bind param failed: ' . htmlspecialchars($stmt->error));
    }

    if (!$stmt->execute()) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    } else {
        echo "New member added successfully";
    }

    $stmt->close();
    header("Location: create-user.php");
    exit();
}

$conn->close();
?>
<html>
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
	<div class="wrapper">
		<div class="dashboard-content">
			<div class="dashboard-content-title wd100">
				<h1>Add Member</h1>
			</div>
			
			<div class="creating-panel wd100">
				<form action="create-user.php" method="post" enctype="multipart/form-data">
					<div class="left-right">
						<div class="user-profile-manage-image">
						<img id="profile_image_preview" src="images/default.png" alt="Profile Image" style="display: none;">
                        </div>
						<label for="profile_image" class="btn-area btn-black-upload wdauto custom-label">Upload</label>
            <input style="display: none;" type="file" name="profile_image" id="profile_image" accept="image/*">
            <input class="btn-area btn-red-upload wdauto" value="Remove" type="button" onclick="removeImage()">
            <input type="hidden" name="remove_image" id="remove_image" value="false">
        </div>
					<div class="left-right">
						<div class="left-p">
							<input type="text" name="username" placeholder="Username">
						</div>
						<div class="right-p">
							<input type="text" name="password" placeholder="Password">
						</div>
					</div>
					<div class="left-right">
						<div class="left-p">
							<input type="email" name="email" placeholder="Email">
						</div>
						<div class="right-p">
							<select name="usertype">
								<option value="admin">Admin</option>
								<option value="user">User</option>
							</select>
						</div>
					</div>
					<div class="left-right">
                        <div class="left-p">
                            <input type="text" placeholder="Member Id" name="member_id">
                        </div>
                        <div class="right-p">
                        <select name="department">
								<option value="it department">IT Department</option>
								<option value="finanace department">Finance Department</option>
							</select>
                        </div>
                    </div>
					<div class="left-right">
						<input class="btn-area wdauto" value="Submit" type="submit">
						<input class="btn-area btn-area-black wdauto" value="Cancel" type="button" onclick="window.location.href='dashboard.php';">
					</div>
				</form>

				<script>
document.getElementById('profile_image').addEventListener('change', function(event) {
                        var reader = new FileReader();
                        reader.onload = function(e) {
                            var imgElement = document.getElementById('profile_image_preview');
                            imgElement.src = e.target.result;
                            imgElement.style.display = 'block';
                        }
                        reader.readAsDataURL(event.target.files[0]);
                    });

                    function removeImage() {
                        var imgElement = document.getElementById('profile_image_preview');
                        imgElement.src = '';
                        imgElement.style.display = 'none';
                        document.getElementById('profile_image').value = '';
                        document.getElementById('remove_image').value = 'true';
                    }
</script>
			</div>
			
			
			
		</div>
	
	
	</div>
	
	<div class="wrapper">
			
		<div class="copyright wd100">
			<p>© CollaborateGov 2024 | All Right Reserved</p>
		</div>
	</div>
	
</body>
</html>
