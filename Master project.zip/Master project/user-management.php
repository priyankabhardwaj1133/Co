<?php
include "db-connection.php";

// Fetch users from the database
$sql = "SELECT id, username, department, image_path FROM signin";
$result = $conn->query($sql);

// Check if the query was successful
if ($result === false) {
    die("Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>User Management</h1>
            </div>
            <div class="user-manage-area wd100">
                <ul>
                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            // Check if image_path already includes "uploads/"
                            $imagePath = strpos($row["image_path"], 'uploads/') === 0 ? $row["image_path"] : 'uploads/' . $row["image_path"];
                            //echo "<li>Checking image path: " . htmlspecialchars($imagePath) . "</li>"; // Debugging step
                            if (!file_exists($imagePath)) {
                                echo "<li>Image not found: " . htmlspecialchars($imagePath) . "</li>";
                            } else {
                                echo "<li>";
                                echo "<div class='user-manage-area-top'>";
                                echo "<div class='user-manage-area-top-image'>";
                                echo "<img src='" . htmlspecialchars($imagePath) . "' alt='User Image'>";
                                echo "</div>";
                                echo "<div class='user-manage-area-top-text'>";
                                echo "<h3>" . htmlspecialchars($row["username"]) . "</h3>";
                                echo "<span class='black'><strong>" . htmlspecialchars($row["department"]) . "</strong></span>";
                                echo "<p>";
                                echo "<span><a href='view-user.php?id=" . htmlspecialchars($row["id"]) . "'>View</a> / <a href='edit-user.php?id=" . htmlspecialchars($row["id"]) . "'>Edit</a></span>";
                                echo "</p>";
                                echo "</div>";
                                echo "</div>";
                                echo "</li>";
                            }
                        }
                    } else {
                        echo "<li>No users found.</li>";
                    }
                    $conn->close();
                    ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>

</body>
</html>
