<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>


	<div class="header-dashboard wd100">
		<div class="wrapper">
			<div class="header wd100">
				<div class="logo">
					<a href="index.php"><img width="230px" src="images/logo.png"></a>
				</div>
				<div class="main-menu dashboard">
					<ul>
						<li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="meeting-management.php">Meeting Management</a></li>
                        <li><a  href="user-management.php">User Management</a></li>
						<li><a href="analytics-reports.php">Analytics & Report</a></li>
					</ul>
				</div>
				<div class="sign-button dashboard-icons">
					<ul>
						<li><a href="#"><img src="images/ic_baseline-notifications.png"></a>
							<div class="dashboard-content-notification wd100 menu-notification">
								<div class="dashboard-content-subtitle  wd100">
									<h2>Notifications</h2>
								</div>
								<ul>
									<li>

										<div class="notification-image">
											<img src="images/about.png">
										</div>
										<div class="notification-text">
											<h4>User Name</h4>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
										</div>
										<div class="notification-date">
											<span>Just Now</span>
										</div>

									</li>
									<li>

										<div class="notification-image">
											<img src="images/about.png">
										</div>
										<div class="notification-text">
											<h4>User Name</h4>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
										</div>
										<div class="notification-date">
											<span>Just Now</span>
										</div>

									</li>
									<li>

										<div class="notification-image">
											<img src="images/about.png">
										</div>
										<div class="notification-text">
											<h4>User Name</h4>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
										</div>
										<div class="notification-date">
											<span>Just Now</span>
										</div>

									</li>
									<li>

										<div class="notification-image">
											<img src="images/about.png">
										</div>
										<div class="notification-text">
											<h4>User Name</h4>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
										</div>
										<div class="notification-date">
											<span>Just Now</span>
										</div>

									</li>
								</ul>
							</div>

						</li>
						<li><a href="help.php"><img src="images/material-symbols_help.png"></a></li>
						<li class="name-profile"><a href="view-profile.php" class="name-circle">PP</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>

	<div class="wrapper">
		<div class="dashboard-content">
			<div class="dashboard-content-title wd100">
				<h1>Help</h1>
			</div>

			<div class="wd100">
				<h2>Welcome to the CollaborateGov Help Center!</h2>
                <p>We're here to ensure you get the most out of CollaborateGov. Whether you're a new user or a seasoned pro, our comprehensive help resources are designed to assist you with any questions or issues you might encounter.</p>
                <h3>Getting Started</h3>
                <h4>1. Introduction to CollaborateGov</h4>
                    <p>
                   - Overview: CollaborateGov is designed to streamline the management of committee and board meetings, making it easier for government departments to handle administrative tasks.<br>
                   - Video Tutorial: Watch our introductory video that provides a tour of the platform’s main features and how to navigate them effectively.<br>
                   - Key Benefits: Learn about the time-saving features and security measures that make CollaborateGov the ideal solution for your organization.
                    </p>
                <h4>2. Setting Up Your Account</h4>
                <p>
                   - Step-by-step guide to creating and configuring your user account.
                </p>
                <p>Follow these steps to sign up and set up your user account.<br>
                   1. Go to the CollaborateGov sign-up page.<br>
                   2. Enter your email address and create a password.<br>
                   3. Verify your email through the confirmation link sent to your inbox.<br>
                   4. Log in to your new account.
                </p>
                <p>- Tips on customizing your profile and notification settings.<br>
                   <strong>Configure Your Profile: </strong>Customize your profile with your personal information, profile picture, and notification preferences.
                   <strong>Set Notification Preferences:</strong> Adjust your settings to receive updates and reminders via email or / and SMS.
                </p>
                <h4>3. Navigating the Dashboard</h4>
                <p>
                - Familiarize yourself with the main dashboard and its key components.<br>
                •	Dashboard Overview: The main dashboard provides a snapshot of your upcoming meetings, recent documents, and important notifications.
                </p>
                <p>
                - Learn how to access and manage different modules within CollaborateGov.<br>
                •	Modules: Learn how to access and manage different modules such as Meetings, Documents, and Members.<br>
                •	Customization: Tailor your dashboard layout to prioritize the information that’s most important to you.
                </p>

                <h3>User Guides</h3>
                <h4>1. Document Management</h4>
                <p>- How to upload, organize, and share documents securely.<br>
                1. Navigate to the Documents module.<br>
                2. Click the 'Upload' button and select your file.<br>
                3. Add a title and description, if necessary, then save.
                </p>
                <p>
                - Best practices for managing document permissions and version control.<br>
                1. Create folders and subfolders to keep your documents organized and easy to find.<br>
                2. Share documents with committee members securely by setting permissions and access levels.
                </p>
                <h4>2. Scheduling and Managing Meetings</h4>
                <p>- Detailed instructions on scheduling meetings, sending invitations, and setting agendas.<br>
                •	Scheduling Meetings:<br>
                1. Go to the Meetings module.<br>
                2. Click ‘Schedule Meeting’ and fill out the details such as date, time, and agenda.<br>
                3. Send invitations to participants directly from the platform.<br>
                </p>
                <p>
                •	Setting Agendas: Outline the meeting agenda and attach relevant documents for participants to review beforehand.
                </p>
                <p>
                - Tips for recording meeting minutes and tracking action items.<br>
                •	Recording Minutes: Use the Minutes feature to take notes during the meeting and distribute them afterward.<br>
                •	Tracking Action Items: Assign tasks and deadlines to participants, and monitor progress through the Action Items tab.
                </p>
                <h4>3. Collaboration Tools</h4>
                <p>- How to use the built-in messaging and file-sharing features.<br>
                <strong>Messaging:</strong> Use the built-in messaging feature to communicate with other members in real-time.<br>
                <strong>File Sharing:</strong> Share files directly through the platform to ensure everyone has access to the latest documents.
                </p>
                <p>- Guidelines for effective communication and collaboration within committees and boards.<br>
                Discussion Threads: Start discussion threads on specific topics to facilitate detailed conversations among members.
                </p>
                <h2>Frequently Asked Questions (FAQs)</h2>
                <h3>General Questions</h3>
                <p><strong>What is CollaborateGov?</strong><br>
                CollaborateGov is a comprehensive software solution designed to simplify the management of committee and board meetings for government departments.
                </p>
                <p><strong>How do I reset my password?</strong><br>
                Click on 'Forgot Password' on the login page, enter your email, and follow the instructions to reset your password.
                </p>
                <p><strong>How can I contact support?</strong><br>
                You can contact our support team via email at support@collaborategov.com or call us at +61 8 1234 5678.
                </p>

                <h4>Technical Questions</h4>
                <p><strong>What are the system requirements for using CollaborateGov?</strong><br>
                CollaborateGov is a web-based platform and can be accessed via any modern web browser. Ensure your browser is updated to the latest version for the best experience.
                </p>
                <p><strong>How do I troubleshoot login issues?</strong><br>
                Ensure that your email and password are entered correctly. If issues persist, use the 'Forgot Password' option or contact support.
                </p>
                <p><strong>What should I do if I encounter a technical error?</strong><br>
                Try refreshing your browser or clearing your cache. If the problem continues, contact our technical support team with details of the error.
                </p>

                <h4>Troubleshooting</h4>
                <p><strong>Common Issues and Solutions</strong></p>
                <p><strong>Login Problems:</strong> If you’re having trouble logging in, make sure your credentials are correct. If you’ve forgotten your password, use the 'Forgot Password' feature to reset it. If the issue persists, contact support.</p>
                <p><strong>Document Upload Errors:</strong> Ensure the document format is supported and the file size is within the allowed limit. Try uploading again, and if you continue to face issues, contact our support team.</p>
                <p><strong>Meeting Scheduling Conflicts:</strong> Check for overlapping meetings in your calendar. Use the conflict resolution feature to suggest alternative times or contact participants to reschedule.</p>

                <h4>Contact Support</h4>
                <p>If you can't find the answer to your question or need further assistance, our support team is here to help!</p>

                <p><strong>Technical Support:</strong><br>
                - Email: support@ collaborategov.com<br>
                - Phone: 1234 567 891</p>

                <p><strong>Sales Inquiries:</strong><br>
                - Email: sales@collaborategov.com<br>
                - Phone: 1234 567 892</p>

                <p><strong>Feedback and Suggestions</strong><br>
                We value your feedback! If you have suggestions for improving CollaborateGov or would like to report a bug, please let us know.
                </p>
                <p><strong>Submit Feedback:</strong><br>
                - Use our Feedback Form to share your thoughts and suggestions.
                </p>
                <p><strong>Join Our Community:</strong><br>
                - Connect with other CollaborateGov users and share tips, ask questions, and learn from each other in our user forums.
                </p>
                <p>Thank you for choosing CollaborateGov. We're committed to providing you with the best possible experience and support.</p>



			</div>



		</div>


	</div>



	<div class="wrapper">

		<div class="copyright wd100">
			<p>© CollaborateGov 2024 | All Right Reserved</p>
		</div>
	</div>

</body>
</html>