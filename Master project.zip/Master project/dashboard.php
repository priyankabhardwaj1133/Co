<?php
include "db-connection.php";

// Fetch upcoming meetings from the database
$sql = "SELECT id, project_name, department, meeting_date, file_name, description FROM meeting WHERE meeting_date >= NOW() ORDER BY meeting_date ASC";
$result = $conn->query($sql);

// Initialize an empty array to hold meetings
$meetings = [];
if ($result) {
    if ($result->num_rows > 0) {    
        while ($row = $result->fetch_assoc()) {
            $meetings[] = $row;
        }
    }
} else {
    echo "Error: " . $conn->error;
}

// Fetch comments and user information from the database
$comments_sql = "
    SELECT comments.comment, comments.comment_date, signin.username, signin.image_path 
    FROM comments 
    JOIN signin ON comments.user_id = signin.id 
    ORDER BY comments.comment_date DESC";
$comments_result = $conn->query($comments_sql);

// Initialize an empty array to hold comments
$comments = [];
if ($comments_result) {
    if ($comments_result->num_rows > 0) {    
        while ($row = $comments_result->fetch_assoc()) {
            $comments[] = $row;
        }
    }
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Dashboard</h1>
            </div>
            <div class="dashboard-content-subtitle wd100">
                <h2>Upcoming Meetings</h2>
            </div>
            <div class="user-manage-area wd100">
                <ul>
                    <?php foreach ($meetings as $meeting): ?>
                    <li>
                        <div class="user-manage-area-top">
                            <div class="user-manage-area-top-text">
                                <h3><?php echo htmlspecialchars($meeting['project_name']); ?></h3>
                                <span><?php echo htmlspecialchars($meeting['meeting_date']); ?></span>
                            </div>
                        </div>
                        <div class="user-manage-area-footer">
                            <a href="edit-meeting.php?id=<?php echo htmlspecialchars($meeting['id']); ?>" class="btn btn-blue">Edit</a>
                            <a href="delete-meeting.php?id=<?php echo htmlspecialchars($meeting['id']); ?>" class="btn btn-red">Cancel</a>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="dashboard-content-subtitle wd100">
                <h2>Notifications</h2>
            </div>

            <div class="dashboard-content-notification wd100">
                <ul>
                    <?php foreach ($comments as $comment): ?>
                    <li>
                        <div class="notification-image">
                            <img src="<?php echo htmlspecialchars($comment['image_path']); ?>" alt="User Image">
                        </div>
                        <div class="notification-text">
                            <h4><?php echo htmlspecialchars($comment['username']); ?></h4>
                            <p><?php echo htmlspecialchars($comment['comment']); ?></p>
                        </div>
                        <div class="notification-date">
                            <span><?php echo htmlspecialchars($comment['comment_date']); ?></span>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>
