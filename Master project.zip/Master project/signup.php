<?php
// Database connection setup
$serverName = "comp9034-group2-ae.database.windows.net"; // Azure server name
$database = "comp9034-group2-db"; // Azure database name
$username = "admincomp9034group2"; // Database username
$password = "flinders@tonsley9034"; // Database password

try {
    $conn = new PDO("sqlsrv:server = $serverName; Database = $database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handling form submission
if (isset($_POST['submit'])) {
    $username = $_POST['user'];
    $email = $_POST['email'];
    $password = $_POST['pass'];

    // Check for existing username
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $count_user = $stmt->rowCount();

    // Check for existing email
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $count_email = $stmt->rowCount();

    if ($count_user == 0 && $count_email == 0) {
        if ($password) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$username, $email, $hash]);
            echo "User successfully registered!";
        } else {
            echo '<script>
            alert("Password is required!");
            window.location.href = "signup.php";
            </script>';
        }
    } else {
        echo '<script>
        alert("User or email already exists!!!");
        window.location.href = "index.php";
        </script>';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Sign Up</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
    <link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wd100">
        <div class="signarea">
            <div class="signarea-content">
                <p><a href="index.php"><img width="70%" src="images/logo.png" alt="Logo"></a></p>
                <p>Are you ready to</p>
                <h1>Sign Up</h1>
                <form name="form" action="signup.php" method="POST">
                    <input type="text" id="user" name="user" placeholder="Name" required>
                    <input type="email" id="email" name="email" placeholder="Email Id" required>
                    <input type="password" id="pass" name="pass" placeholder="Password" required>
                    <input class="btn" name="submit" value="Sign Up" type="submit" />
                </form>
                <p align="middle"><strong>Already have an account? <a href="signin.php">Sign in</a></strong></p>
            </div>
            <div class="signarea-image" style="background:url('images/signin.png') no-repeat center center / cover;"></div>
        </div>
    </div>
</body>
</html>
