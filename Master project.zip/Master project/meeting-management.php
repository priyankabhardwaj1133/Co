<?php
include 'db-connection.php';

// Check if a search query is set
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Construct the SQL query
$sql = "SELECT * FROM meeting";
if ($search) {
    $sql .= " WHERE project_name LIKE '%$search%' OR project_type LIKE '%$search%' OR department LIKE '%$search%' OR description LIKE '%$search%'";
}

// Execute the SQL query and handle potential errors
$result = $conn->query($sql);

if ($result === false) {
    die("Database query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Meeting Management</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Meeting Management</h1>
            </div>

            <div class="dashboard-table wd100">
                <div class="search-bar">
                    <form method="post" action="">
                        <input type="text" name="search" placeholder="Search" value="<?php echo htmlspecialchars($search); ?>">
                    </form>
                </div>
                <ul>
                    <li class="head">
                        <div class="dashboard-checkbox">
                            <input type="checkbox">
                        </div>
                        <div class="dashboard-name">
                            Name
                        </div>
                        <div class="dashboard-department">
                            Department
                        </div>
                        <div class="dashboard-documents">
                            Documents
                        </div>
                        <div class="dashboard-description">
                            Description
                        </div>
                        <div class="dashboard-date">
                            Date/Time
                        </div>
                        <div class="dashboard-more">
                            More actions
                        </div>
                    </li>

                    <?php
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<li>";
                            echo "<div class='dashboard-checkbox'><input type='checkbox'></div>";
                            echo "<div class='dashboard-name'>" . htmlspecialchars($row['project_name']) . "</div>";
                            echo "<div class='dashboard-department'>" . htmlspecialchars($row['department']) . "</div>";
                            echo "<div class='dashboard-documents'><a href='#'>" . htmlspecialchars($row['file_name']) . "</a></div>";
                            echo "<div class='dashboard-description'>" . htmlspecialchars($row['description']) . "</div>";
                            echo "<div class='dashboard-date'>" . htmlspecialchars($row['meeting_date']) . "</div>";
                            echo "<div class='dashboard-more'>
                                    <a href='view-meeting-manager.php?id=" . htmlspecialchars($row['id']) . "'><img src='images/view.png'></a>
                                    <a href='edit-meeting.php?id=" . htmlspecialchars($row['id']) . "'><img src='images/edit.png'></a>
                                    <a href='delete-meeting.php?id=" . htmlspecialchars($row['id']) . "'><img src='images/delete.png'></a>
                                  </div>";
                            echo "</li>";
                        }
                    } else {
                        echo "<li>No meetings found.</li>";
                    }
                    $conn->close();
                    ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>
