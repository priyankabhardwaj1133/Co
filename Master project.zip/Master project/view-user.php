<?php
include "db-connection.php";

// Check if ID is set in the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);

    // Prepare the query to fetch the specific member
    $stmt = $conn->prepare("SELECT * FROM signin WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Check if a member was found
    if ($result->num_rows > 0) {
        $signin = $result->fetch_assoc();
        //var_dump($signin); // Optional: Debugging output
    } else {
        echo "No member found with the provided ID.";
        exit;
    }

    $stmt->close();
} else {
    echo "Invalid member ID.";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>View User</h1>
            </div>

            <div class="view-panel wd100">
                <div class="wd100">
                    <h6>Profile Image</h6>
                    <?php if (!empty($signin['image_path'])): ?>
                        <p><img src="<?php echo htmlspecialchars($signin['image_path']); ?>" alt="Profile Image" width="150px"></p>
                    <?php else: ?>
                        <p>No profile image available.</p>
                    <?php endif; ?>
                </div>

                <div class="wd100">
                    <h6>Username</h6>
                    <p><?php echo htmlspecialchars($signin['username']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Password</h6>
                    <p><?php echo htmlspecialchars($signin['password']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Email</h6>
                    <p><?php echo htmlspecialchars($signin['email']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Role</h6>
                    <p><?php echo htmlspecialchars($signin['usertype']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Department</h6>
                    <p><?php echo htmlspecialchars($signin['department']); ?></p>
                </div>

				<div class="wd100">
                    <h6>Member_id</h6>
                    <p><?php echo htmlspecialchars($signin['member_id']); ?></p>
                </div>
                <div class="wd100">
                    <h6>More Actions</h6>
                    <p>
					<a href="edit-user.php?id=<?php echo $signin['id']; ?>"><img src="images/edit.png"></a>
					    <a href="delete-user.php?id=<?php echo $signin['id']; ?>"><img src="images/delete.png"></a>
					</p>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>

</body>
</html>
