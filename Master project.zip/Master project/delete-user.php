<?php
require_once 'db-connection.php'; // Include your database connection file

// Redirect to the dashboard if 'id' parameter is missing or invalid
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "Invalid or missing user ID.";
    header("Location: dashboard.php"); // Redirect to dashboard.php
    exit();
}

$id = intval($_GET['id']);

// Enable error reporting for the database connection
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Fetch user data from the database
    $sql = "SELECT * FROM signin WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        throw new Exception('Statement prepare failed: ' . $conn->error);
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    // Redirect to the dashboard if user data was not found
    if (!$user) {
        $_SESSION['error'] = "User not found.";
        header("Location: dashboard.php"); // Redirect to dashboard.php
        exit();
    }

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Delete user data from the database
        $sql = "DELETE FROM signin WHERE id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            throw new Exception('Statement prepare failed: ' . $conn->error);
        }

        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $_SESSION['success'] = "User deleted successfully.";
            $stmt->close();
            header("Location: user-management.php"); // Redirect to dashboard.php
            exit();
        } else {
            $_SESSION['error'] = "Failed to delete user.";
            $stmt->close();
        }
    }
} catch (Exception $e) {
    $_SESSION['error'] = "Error: " . $e->getMessage();
    header("Location: dashboard.php"); // Redirect to dashboard.php
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Delete User</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
<div class="wrapper">
    <div class="dashboard-content">
        <div class="dashboard-content-title wd100">
            <h1>Delete User</h1>
        </div>

        <div class="creating-panel wd100">
            <?php if (isset($_SESSION['error'])): ?>
                <div class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <form action="delete-user.php?id=<?php echo htmlspecialchars($user['id']); ?>" method="POST">
                <p>Are you sure you want to delete the following user?</p>
                <ul>
                    <li><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></li>
                    <li><strong>Password:</strong> <?php echo htmlspecialchars($user['password']); ?></li>
                    <li><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></li>
                    <li><strong>Role:</strong> <?php echo htmlspecialchars($user['usertype']); ?></li>
                    <li><strong>Department:</strong> <?php echo htmlspecialchars($user['departmenr']); ?></li>
                    <li><strong>Member_Id:</strong> <?php echo htmlspecialchars($user['member_id']); ?></li>
                    <li><strong>Image Path:</strong> <?php echo htmlspecialchars($user['image_path']); ?></li>
                </ul>
                <div class="left-right">
                    <input class="btn-area wdauto" value="Delete" type="submit">
                    <input class="btn-area btn-area-black wdauto" value="Cancel" type="button" onclick="window.location.href='dashboard.php';">
                </div>
            </form>
        </div>
    </div>
</div>

<div class="wrapper">
    <div class="copyright wd100">
        <p>© CollaborateGov 2024 | All Right Reserved</p>
    </div>
</div>

</body>
</html>
