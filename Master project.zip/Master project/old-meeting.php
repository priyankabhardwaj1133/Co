<?php
include "user-header.php";
include "db-connection.php"; // Include your database connection file

// Fetch old meetings from the database
$meetings_query = "SELECT * FROM meeting WHERE meeting_date < NOW() ORDER BY meeting_date ASC";
$meetings_result = $conn->query($meetings_query);
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Old Meeting</h1>
            </div>
            <div class="user-manage-area wd100">
                <ul>
                <?php while($meeting = $meetings_result->fetch_assoc()): ?>
                    <li>
                        <div class="user-manage-area-top">
                            <div class="user-manage-area-top-text">
                                <h3><?php echo $meeting['project_name']; ?></h3>
                                <p><?php echo $meeting['description']; ?></p>
                                <span><?php echo date("d/m/Y - h:i A", strtotime($meeting['meeting_date'])); ?></span>
                            </div>
                        </div>
                        <div class="user-manage-area-middle">
                            <span><?php echo $meeting['department']; ?></span>
                        </div>
                        <div class="user-manage-area-footer toggle-outer">
                            <a href="view-meeting.php?id=<?php echo $meeting['id']; ?>#comment-feedback" class="btn btn-blue">Comments</a>
                        </div>
                    </li>
                <?php endwhile; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>
