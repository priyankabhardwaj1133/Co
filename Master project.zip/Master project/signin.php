<?php
session_start();
include "db-connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $member_id = $_POST["member_id"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Use prepared statements to prevent SQL injection
    $sql = "SELECT * FROM signin WHERE member_id = ? AND username = ? AND password = ?";
    $stmt = $conn->prepare($sql);

    // Check if prepare() failed
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    $stmt->bind_param('sss', $member_id, $username, $password);
    
    // Execute the statement
    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result) {
            $row = $result->fetch_assoc();

            if ($row) {
                $_SESSION["user_id"] = $row["id"];
                $_SESSION["username"] = $username;
                echo "<pre>";
                print_r($_SESSION);
                echo "</pre>";
                
                if ($row["usertype"] == "user") {
                    $_SESSION["username"] = $username;
                    header("Location: dashboard-members.php");
                    exit();
                } elseif ($row["usertype"] == "admin") {
                    $_SESSION["username"] = $username;
                    header("Location: dashboard.php");
                    exit();
                }
            } else {
                echo "Member ID, username, or password incorrect";
            }
        } else {
            echo "Error fetching result: " . htmlspecialchars($stmt->error);
        }
    } else {
        echo "Execute failed: " . htmlspecialchars($stmt->error);
    }
    
    // Close statement
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Sign In</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>

<div class="wd100">
    <div class="signarea">
        <div class="signarea-content">
            <p><a href="index.php"><img width="70%" src="images/logo.png"></a></p>
            <p>Welcome Back In</p>
            <h1>Sign in</h1>
            <form name="form" action="signin.php" method="POST">
                <input type="text" id="username" name="username" placeholder="Username" required>
                <input type="password" id="password" name="password" placeholder="Password" required>
                <input type="text" id="member_id" name="member_id" placeholder="Member ID" required>

                <p align="right"><a class="grey" href="forgot-password.php">Forgot Password</a></p>
                <input class="btn" value="Sign in" type="submit" name="submit" />
            </form>
            <p align="middle"><strong>Don't have an account yet? <a href="signup.php">Sign up</a></strong></p>
        </div>
        <div class="signarea-image" style="background:url('images/signin.png') no-repeat center center / cover;"></div>
    </div>
</div>

</body>
</html>
