<?php
session_start(); // Start the session
require 'db-connection.php'; // Include your database connection file

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Initialize variables
$username = $password = $member_id = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $member_id = trim($_POST['member_id']);

    // Validate input (e.g., check if fields are empty)
    if (empty($username) || empty($password) || empty($member_id)) {
        echo "All fields are required.";
        exit;
    }

    // Get user ID from session or other method
    if (!isset($_SESSION['user_id'])) {
        echo "User not logged in.";
        exit;
    }
    $user_id = $_SESSION['user_id'];

    // Update user profile in the database
    $stmt = $conn->prepare("UPDATE signin SET username = ?, password = ?, member_id = ? WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("sssi", $username, $password, $member_id, $user_id);

    if ($stmt->execute()) {
        // Setting a success message in session to display on redirect
        $_SESSION['success'] = "User updated successfully.";
        // Redirect to profile view page or dashboard
        header("Location: view-profile.php");
        exit;
    } else {
        echo "Error updating profile: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_SESSION['success'])) {
    // Display success message if redirected from a successful update
    echo $_SESSION['success'];
    unset($_SESSION['success']); // Clear the message after displaying
} else {
    // Fetch user data for editing
    if (!isset($_SESSION['user_id'])) {
        echo "User not logged in.";
        exit;
    }
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("SELECT username, member_id, password FROM signin WHERE id = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($username, $member_id, $password);
    $stmt->fetch();
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include "user-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Edit Profile</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Edit Profile</h1>
            </div>
            <div class="creating-panel wd100">
                <form method="post" action="edit-profile.php">
                    <div class="left-right">
                        <div class="left-p">
                            <input type="text" name="username" placeholder="Username" value="<?php echo htmlspecialchars($username); ?>" required>
                        </div>
                        <div class="right-p">
                            <input type="text" name="password" placeholder="Password" value="<?php echo htmlspecialchars($password); ?>" required>
                        </div>
                    </div>
                    <div class="left-right">
                        <div class="left-p">
                            <input type="text" name="member_id" placeholder="Member Id" value="<?php echo htmlspecialchars($member_id); ?>" required>
                        </div>
                    </div>
                    <div class="left-right">
                        <input class="btn-area wdauto" value="Submit" type="submit">
                        <input class="btn-area btn-area-black wdauto" value="Cancel" type="button" onclick="window.location.href='view-profile.php'">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>
