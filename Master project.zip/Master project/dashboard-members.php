<?php
include "user-header.php";
include "db-connection.php"; // Include your database connection file

// Fetch upcoming meetings from the database
$meetings_query = "SELECT * FROM meeting WHERE meeting_date > NOW() ORDER BY meeting_date ASC";
$meetings_result = $conn->query($meetings_query);
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Dashboard</h1>
            </div>
            <div class="dashboard-content-subtitle wd100">
                <h2>Upcoming Meeting</h2>
            </div>
            <div class="user-manage-area wd100">
                <ul>
                <?php while($meeting = $meetings_result->fetch_assoc()): ?>
                    <li>
                        <div class="user-manage-area-top">
                            
                            <div class="user-manage-area-top-text">
                                <h3><?php echo $meeting['project_name']; ?></h3>
                                <p><?php echo $meeting['description']; ?></p>
                                <span><?php echo date("d/m/Y - h:i A", strtotime($meeting['meeting_date'])); ?></span>
                            </div>
                        </div>
                        <div class="user-manage-area-middle">
                            <span><?php echo $meeting['department']; ?></span>
                        </div>
                        <div class="user-manage-area-footer">
                            <a href="view-meeting.php?id=<?php echo $meeting['id']; ?>" class="btn btn-blue">View Meeting</a>
                        </div>
                    </li>
                <?php endwhile; ?>
                </ul>
            </div>

            <div class="dashboard-content-subtitle wd100">
                <h2>Notifications</h2>
            </div>

            <div class="dashboard-content-notification wd100">
                <ul>
                    <li>
                        <div class="notification-image">
                            <img src="images/about.png">
                        </div>
                        <div class="notification-text">
                            <h4>Notification</h4>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="notification-date">
                            <span>Just Now</span>
                        </div>
                    </li>
                    <li>
                        <div class="notification-image">
                            <img src="images/about.png">
                        </div>
                        <div class="notification-text">
                            <h4>Notification</h4>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="notification-date">
                            <span>Just Now</span>
                        </div>
                    </li>
                    <li>
                        <div class="notification-image">
                            <img src="images/about.png">
                        </div>
                        <div class="notification-text">
                            <h4>Notification</h4>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="notification-date">
                            <span>Just Now</span>
                        </div>
                    </li>
                    <li>
                        <div class="notification-image">
                            <img src="images/about.png">
                        </div>
                        <div class="notification-text">
                            <h4>Notification</h4>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                        <div class="notification-date">
                            <span>Just Now</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>
