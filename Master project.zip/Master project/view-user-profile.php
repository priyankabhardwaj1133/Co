<?php
ob_start(); // Start output buffering
session_start(); // Start the session
include "user-header.php";
include "db-connection.php"; // Include your database configuration file



// Check if the user is logged in
if(!isset($_SESSION['user_id'])){
    header("Location: signin.php");
    exit();
}

// Get user ID from the session
$user_id = $_SESSION['user_id'];

// Prepare SQL statement
$sql = "SELECT member_id, username, usertype FROM signin WHERE id = ?";
$stmt = $conn->prepare($sql);

// Check if prepare() failed
if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    // Handle case where user data is not found
    echo "User data not found.";
    exit();
}

// Get the current date and time
$date_time = date('d-m-y / h:iA');
ob_end_flush(); // End output buffering and flush the output
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>View Profile</h1>
            </div>

            <div class="view-panel wd100">
                <div class="wd100">
                    <h6>Member ID</h6>
                    <p><?php echo htmlspecialchars($user['member_id']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Username</h6>
                    <p><?php echo htmlspecialchars($user['username']); ?></p>
                </div>

                <div class="wd100">
                    <h6>User Type</h6>
                    <p><?php echo htmlspecialchars($user['usertype']); ?></p>
                </div>

                <div class="wd100">
                    <h6>Calendar & Time</h6>
                    <p><?php echo $date_time; ?></p>
                </div>

                <div class="wd100">
                    <h6>More Actions</h6>
                    <p><a href="edit-user-profile.php"><img src="images/edit.png" alt="Edit Profile"></a> 
                    <a href="logout.php"><img src="images/logout.png" alt="Logout"></a></p>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="copyright wd100">
            <p>© CollaborateGov 2024 | All Right Reserved</p>
        </div>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
