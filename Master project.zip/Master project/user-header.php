<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$current_page = basename($_SERVER['PHP_SELF']); // Get the current page name
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
<style>
/* Add CSS for active link */
.main-menu a.active {
    font-weight: bold;
    color: #000; /* Adjust color as needed */
}
</style>
</head>
<body>
    <div class="header-dashboard wd100">
        <div class="wrapper">
            <div class="header wd100">
                <div class="logo">
                    <a href="index.php"><img width="230px" src="images/logo.png" alt="Logo"></a>
                </div>
                <div class="main-menu dashboard">
                    <ul>
                        <li><a href="dashboard-members.php" class="<?php echo $current_page == 'dashboard-members.php' ? 'active' : ''; ?>">Dashboard</a></li>
                        <li><a href="upcoming-meeting.php" class="<?php echo $current_page == 'upcoming-meeting.php' ? 'active' : ''; ?>">Upcoming Meeting</a></li>
                        <li><a href="old-meeting.php" class="<?php echo $current_page == 'old-meeting.php' ? 'active' : ''; ?>">Old Meeting</a></li>
                    </ul>
                </div>
                <div class="sign-button dashboard-icons">
                    <ul>
                        
                        <li><a href="help.php"><img src="images/material-symbols_help.png" alt="Help"></a></li>
                        <li class="name-profile"><a href="view-user-profile.php" class="name-circle">
                            <?php
                            // Check if the username is set in the session and display it
                            if (isset($_SESSION["username"])) {
                                echo "Welcome, " . htmlspecialchars($_SESSION["username"]);
                            } else {
                                echo "Username not set.";
                            }
                            ?>
                        </a></li>
                        <li><a href="logout.php"><img src="images/logout.png" alt="Logout"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
