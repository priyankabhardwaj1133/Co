<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>



	<div class="wrapper">
		<div class="header wd100">
			<div class="logo">
				<a href="index.php"><img width="230px" src="images/logo.png"></a>
			</div>
			<div class="main-menu">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="#aboutus">About us</a></li>
					<li><a href="#news">News & Article</a></li>
				</ul>
			</div>
			<div class="sign-button">
				<a class="btn-area sign-icon" href="signin.php">Sign In</a>
			</div>
		</div>
	</div>

	<div class="banner-area wd100" style=" background:url('images/banner.png') no-repeat center center / cover #000">
		<div class="wrapper">
			<div class="banner">
				<div>
					<h1>Empowering Boards and Committees with Seamless Solutions</h1>
					<p>our platform redefines how governance is conducted. We offer a comprehensive solution that simplifies meeting management, facilitates document access, and enhances collaboration among members. Our platform is designed to be user-friendly and secure, ensuring that board members can focus on their responsibilities without being bogged down by administrative tasks. With our solution, boards and committees can operate more efficiently, make informed decisions, and drive positive change in their organizations.</p>
					<a class="btn-area sign-icon" href="signin.php">Sign In</a>
				</div>
			</div>
		</div>
	</div>

	<div class="wrapper">
		<div id="aboutus" class="wd100 about-section">
			<div class="about-left">
				<h5>About Us</h5>
				<h2>Welcome to CollaborateGov!</h2>
				<p>At CollaborateGov, we believe in simplifying committee and board management for government departments and organizations. Our intuitive software solution empowers you to streamline meeting administration, securely distribute documentation, and enhance collaboration among members.</p>
				<h4>Key Features:</h4>
				<ul class="features">
					<li class="doc"><h4>Secure Document Management</h4></li>
					<li class="admin-meet"><h4>Meeting Administration</h4></li>
					<li class="collab-tool"><h4>Collaboration Tools</h4></li>
				</ul>
				<p>Ready to experience the benefits of CollaborateGov? <a href="signin.php">Schedule a demo today!</a></p>
			</div>
			<div class="about-right">
				<img src="images/about.png">
			</div>
		</div>
	</div>

	<div class="grey wd100">
		<div class="wrapper">
			<div class="wd100 how-works">
				<h2>Benefits</h2>

				<ul>
					<li>
						<h3>Cost Savings</h3>
						<p>By eliminating the need for multiple off-the-shelf software packages, CollaborateGov helps you save on software costs while maximizing your return on investment.</p>
					</li>
					<li>
						<h3>Increased Efficiency</h3>
						<p>Experience significant time savings and improved productivity with CollaborateGov's automated meeting administration and document management features.</p>
					</li>
					<li>
						<h3>Enhanced Security</h3>
						<p>Rest easy knowing that your sensitive meeting documentation is protected by CollaborateGov's advanced security measures, including encryption and access controls.</p>
					</li>
				</ul>
			</div>
		</div>
	</div>



	<div class="wrapper">
		<div id="news" class="wd100 news-article">
			<h2 align="middle">News & Articles</h2>
			<ul>
				<li>
					<div>
						<div class="image-news-area"><img src="images/news1.png"></div>
						<div class="text-news-area">
							<span class="news-meta"><img src="images/calendar.png"> 02 Apr 2024</span>
							<h4>Temporary Reconstruction Authority appointment criticised</h4>
							<p><a href="#">Learn more <img src="images/arrow.png"></a></p>
						</div>
					</div>
				</li>

				<li>
					<div>
						<div class="image-news-area"><img src="images/melbourne.png"></div>
						<div class="text-news-area">
							<span class="news-meta"><img src="images/calendar.png"> 02 Apr 2024</span>
							<h4>Melbourne Lord Mayor Sally Capp to bow out after six years</h4>
							<p><a href="#">Learn more <img src="images/arrow.png"></a></p>
						</div>
					</div>
				</li>

				<li>
					<div>
						<div class="image-news-area"><img src="images/abs.png"></div>
						<div class="text-news-area">
							<span class="news-meta"><img src="images/calendar.png"> 02 Apr 2024</span>
							<h4>ABS confirms record population boom in capital cities</h4>
							<p><a href="#">Learn more <img src="images/arrow.png"></a></p>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</div>






	<div class="cta wd100">
		<div class="left-cta gradient">
			<h2>About CollaborateGov</h2>
			<p>CollaborateGov revolutionizes governance for boards and committees by providing a user-friendly, secure platform that simplifies meeting management and document access. Our comprehensive solution enhances collaboration and efficiency, allowing members to focus on their responsibilities. Experience the benefits of streamlined administration and advanced security with CollaborateGov, and schedule a demo today to see how we can transform your organization.</p>

		</div>
		<div class="right-cta" style=" background:url('images/banner.png') no-repeat center center / cover #000"></div>
	</div>

	<div class="wrapper">
		<div class="footer wd100">
			<div class="foot1">
				<h4>Browse</h4>
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="#aboutus">About us</a></li>
				</ul>
			</div>

			<div class="foot1">
				<h4>Contact</h4>
				<ul>
					<li class="email-icon"><a href="#">admin@admin.com</a></li>
					<li class="phone-icon"><a href="#">1234 567 890</a></li>
				</ul>
			</div>
			<div class="foot1 foot-sign">
				<a class="btn-area sign-icon" href="signin.php">Sign In</a>
			</div>
		</div>

		<div class="copyright wd100">
			<p>© CollaborateGov 2024 | All Right Reserved</p>
		</div>
	</div>
</body>
</html>