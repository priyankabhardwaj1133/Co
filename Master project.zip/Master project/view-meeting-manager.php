<?php
include "db-connection.php";

// Check if ID is set in the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);

    // Prepare the query to fetch the specific meeting
    $stmt = $conn->prepare("SELECT * FROM meeting WHERE id = ?");
    
    // Check if the prepare() method succeeded
    if ($stmt === false) {
        die('Prepare() failed: ' . htmlspecialchars($conn->error));
    }
    
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a meeting was found
    if ($result->num_rows > 0) {
        $meeting = $result->fetch_assoc();
    } else {
        echo "No meeting found with the provided ID.";
        $stmt->close();
        $conn->close();
        exit;
    }

    $stmt->close();
} else {
    echo "Invalid meeting ID.";
    exit;
}

$conn->close();
?>
<html>
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>View Meeting Details</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
</head>
<body>
	<div class="wrapper">
		<div class="dashboard-content">
			<div class="dashboard-content-title wd100">
				<h1>View Meeting Details</h1>
			</div>

			<div class="view-panel wd100">
				<div class="wd100">
					<h6>Project Name</h6>
					<p><?php echo htmlspecialchars($meeting['project_name']); ?></p>
				</div>

				<div class="wd100">
					<h6>Department</h6>
					<p><?php echo htmlspecialchars($meeting['department']); ?></p>
				</div>

				<div class="wd100">
				<h6>Calendar & Time</h6>
				<p><?php echo htmlspecialchars($meeting['meeting_date']); ?></p>
				</div>

				<div class="wd100">
					<h6>Documents</h6>
					<p><a href="uploads/<?php echo htmlspecialchars($meeting['file_name']); ?>" target="_blank"><?php echo htmlspecialchars($meeting['file_name']); ?></a></p>
				</div>
				<div class="wd100">
					<h6>Description</h6>
					<p><?php echo htmlspecialchars($meeting['description']); ?></p>
				</div>

				<div class="wd100">
					
				</div>

				<div class="wd100">
					<h6>More Actions</h6>
					<p>
						<a href="edit-meeting.php?id=<?php echo $meeting['id']; ?>"><img src="images/edit.png"></a>
					    <a href="delete-meeting.php?id=<?php echo $meeting['id']; ?>"><img src="images/delete.png"></a>
					</p>
				</div>
			</div>
		</div>
	</div>

	<div class="wrapper">
		<div class="copyright wd100">
			<p>© CollaborateGov 2024 | All Right Reserved</p>
		</div>
	</div>

</body>
</html>
