<?php
include "db-connection.php";

// Check if id is set via GET or POST and fetch initial data if needed
$id = isset($_GET['id']) ? $_GET['id'] : (isset($_POST['id']) ? $_POST['id'] : null);
if ($id === null) {
    die('Error: Meeting ID is required.');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $projectName = $_POST['project_name'] ?? '';
    $department = $_POST['department'] ?? '';
    $meetingDate = $_POST['meeting_date'] ?? '';
    $description = $_POST['description'] ?? '';
    $fileName = '';

    // Handle file upload if included
    if (isset($_FILES['file_upload']) && $_FILES['file_upload']['error'] == UPLOAD_ERR_OK) {
        $targetDirectory = "uploads/";
        $fileName = basename($_FILES["file_upload"]["name"]);
        $targetFilePath = $targetDirectory . $fileName;
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

        // Check if file type is allowed
        $allowedFileTypes = ['jpg', 'png', 'pdf', 'docx']; // Example allowed types
        if (in_array($fileType, $allowedFileTypes)) {
            if (!file_exists($targetDirectory)) {
                mkdir($targetDirectory, 0777, true);
            }

            if (!file_exists($targetFilePath)) {
                if (move_uploaded_file($_FILES["file_upload"]["tmp_name"], $targetFilePath)) {
                    echo "The file " . htmlspecialchars($fileName) . " has been uploaded.";
                } else {
                    echo "Error uploading your file.";
                }
            } else {
                echo "Sorry, file already exists.";
            }
        } else {
            echo "Invalid file type.";
        }
    } else {
        // Fetch existing file name if no new file is uploaded
        $stmt = $conn->prepare("SELECT file_name FROM meeting WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($existingFileName);
        $stmt->fetch();
        $fileName = $existingFileName;
        $stmt->close();
    }

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE meeting SET project_name = ?, department = ?, meeting_date = ?, file_name = ?, description = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $projectName, $department, $meetingDate, $fileName, $description, $id);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to the view-meeting-manager page with the selected ID
        header("Location: view-meeting-manager.php?id=" . $id);
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

// Fetch existing data for the form
$stmt = $conn->prepare("SELECT * FROM meeting WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$meeting = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include "admin-header.php"; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Edit Meeting</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" media="all" />
<style>
    .file-upload-wrapper {
        position: relative;
        overflow: hidden;
        display: inline-block;
    }

    .file-upload-wrapper input[type="file"] {
        font-size: 100px;
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
    }

    .file-upload-button {
        background-color: #f44336;
        color: white;
        padding: 8px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
</style>
</head>
<body>
    <div class="wrapper">
        <div class="dashboard-content">
            <div class="dashboard-content-title wd100">
                <h1>Edit Meeting</h1>
            </div>
            <div class="creating-panel wd100">
                <form action="edit-meeting.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($meeting['id']); ?>">
                    <div class="left-right">
                        <div class="left-p">
                            <input type="text" name="project_name" value="<?php echo htmlspecialchars($meeting['project_name']); ?>" placeholder="Project Name">
                        </div>
                        <div class="right-p">
                        <select name="department">
                                <option value="it department" <?php echo $meeting['department'] == 'it department' ? 'selected' : ''; ?>>IT Department</option>
                                <option value="finance department" <?php echo $meeting['department'] == 'finance department' ? 'selected' : ''; ?>>Finance Department</option>
                            </select>
                        </div>
                    </div>
                    <div class="left-right">
                        <div class="left-p">
                        <input type="date" name="meeting_date" value="<?php echo htmlspecialchars($meeting['meeting_date']); ?>" placeholder="Calendar & Time">
                        </div>
                        <div class="right-p">
                        <input type="file" class="btn grey wdauto" name="file_upload" id="file_upload">
                            <label for="file_upload"><?php echo $meeting['file_name'] ? htmlspecialchars($meeting['file_name']) : 'No File Chosen'; ?></label>
                        </div>
                    </div>
                    <div class="left-right">
                        <textarea name="description" placeholder="Description"><?php echo htmlspecialchars($meeting['description']); ?></textarea>
                    </div>
                    <div class="left-right">
                        <input class="btn-area wdauto" value="Submit" type="submit">
                        <input class="btn-area btn-area-black wdauto" value="Cancel" type="button" onclick="window.location.href='dashboard.php';">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<script>
document.getElementById('file_upload').addEventListener('change', function() {
    var fileName = this.files[0] ? this.files[0].name : 'No File Chosen';
    this.nextElementSibling.innerHTML = fileName;
});
</script>
